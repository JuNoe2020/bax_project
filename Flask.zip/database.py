import pandas as pd

def save(data_1, data_2, data_3, data_4, data_5, data_6, data_7, data_8, data_9):
    idx = len(pd.read_csv("database.csv"))
    new_df = pd.DataFrame({"data_1":data_1,
                           "data_2":data_2,
                           "data_3":data_3,
                           "data_4":data_4,
                           "data_5":data_5,
                           "data_6":data_6,
                           "data_7":data_7,
                           "data_8":data_8,
                           "data_9":data_9}, 
                         index = [idx])
    new_df.to_csv("database.csv", mode="a", header = False)
    return new_df

def load_list():
    house_list = []
    df = pd.read_csv("database.csv")
    for i in range(len(df)):
        house_list.append(df.iloc[i].tolist())
    print(house_list)
    # return house_list

def now_index():
    df = pd.read_csv("database.csv")
    return len(df)-1


# def load_house(idx):
#     df = pd.read_csv("database.csv")
#     house_inf = df.iloc[idx]
#     return house_info


if __name__ =="__main__":
    load_list()