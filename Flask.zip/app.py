from flask import Flask, render_template, request
import sys
application = Flask(__name__)
import database
import preprocessing
import pandas as pd

@application.route("/")
def hello():
    return render_template("hello.html")

@application.route("/apply")
def apply():
    return render_template("apply.html")

@application.route("/applydata", methods=['POST'])
def applydata():
    data_1 = request.form['data_1']
    data_2 = request.form['data_2']
    data_3 = request.form['data_3']
    data_4 = request.form['data_4']
    data_5 = request.form['data_5']
    data_6 = request.form['data_6']
    data_7 = request.form['data_7']
    data_8 = request.form['data_8']
    data_9 = request.form['data_9']
    database.save(data_1, data_2, data_3, data_4, data_5, data_6, data_7, data_8, data_9)
    df = pd.read_csv('./database.csv')
    df = df.sort_index(ascending=False)
    df.reset_index(inplace=True)
    df = preprocessing.txt(df, ' data_1', ' data_2', ' data_3',' data_4',' data_5',' data_6',' data_7',' data_8',' data_9')
    alpha_dic = pd.read_csv('./untokenized_eng_df.csv')
    df = preprocessing.kor(df, alpha_dic)
    # df = preprocessing.input(df)
    print(df)
    # return render_template("applydata.html")

@application.route("/list")
def list():
    return render_template("list.html")



if __name__ == "__main__":
    application.run(host='0.0.0.0')
