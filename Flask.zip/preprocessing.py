# 각 BM 세그먼트를 하나의 Text로 합치는 함수
# df[1-9]는 각각의 데이터프임
# column[1-9]는 텍스트가 있는 각각의 열
import pandas as pd

def txt(df, column1, column2, column3, column4, 
        column5, column6, column7, column8, column9):
    total_df = pd.DataFrame()
    total_df['text'] = "고객 세그먼트는 "+ df[column1] + "." +\
                " 가치제안은 " + df[column2] + "." +\
                " 마케팅채널은 " + df[column3] + "." +\
                " 고객관계는 " + df[column4] + "." +\
                " 수익원은 " + df[column5] + "." +\
                " 핵심활동은 " + df[column6] + "." +\
                " 핵심자원은 " + df[column7] + "." +\
                " 핵심파트너는 " + df[column8] + "." +\
                " 비용구조는 " + df[column9] + "."
    total_df['text'] = total_df['text'].replace('\n', ",")
    return total_df

# 알파벳사전 불러오기
alpha_dic = pd.read_csv('./untokenized_eng_df.csv')

# 알파벳단어를 한글로 바꾸는 함수
# df:변환대상이되는 데이터프레임
# alpha_dic: 알파벳사전
# text_column, untoken_column, kor_column 따로 선언하지 않아도됨
# (df와 alpha_dic의 컬럼명 변경시 입력필요)

def kor(df, alpha_dic, text_column='text', 
               untoken_column='untokenized_word', kor_column='kor'):
    
    alpha_dic = alpha_dic[[untoken_column, kor_column]]
    alpha_dic.dropna(inplace=True)
    alpha_dic.reset_index(inplace=True)

    words = df[text_column][0].split(" ")
    for word in words:
        for i in range(len(alpha_dic)):
            if word == alpha_dic[untoken_column][i]: 
                df.loc[[0],[text_column]] = df[text_column][0].replace(word, alpha_dic[kor_column][i])
    return df
