from re import A
from flask import Flask, render_template, request, redirect, url_for
import sys
application = Flask(__name__)
application.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
import data
import preprocessing
import time
from KoBERT.kobert.utils import get_tokenizer
from KoBERT.kobert.pytorch_kobert import get_pytorch_kobert_model
import gluonnlp as nlp
import torch
from torch import nn
from torch.utils.data import Dataset
import pandas as pd
import numpy as np
import data_load

@application.after_request
def add_header(r):
    """
    Add headers to both force latest IE rendering engine or Chrome Frame,
    and also to cache the rendered page for 10 minutes.
    """
    r.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    r.headers["Pragma"] = "no-cache"
    r.headers["Expires"] = "0"
    r.headers['Cache-Control'] = 'public, max-age=0'
    return r

@application.route("/")
def hello():
    return render_template("hello.html")

@application.route('/test')
def test():
    return render_template('apply.html')

@application.route('/apply', methods=['POST'])
def apply():
    data_1 = request.form['data_1']
    data_2 = request.form['data_2']
    data_3 = request.form['data_3']
    data_4 = request.form['data_4']
    data_5 = request.form['data_5']
    data_6 = request.form['data_6']
    data_7 = request.form['data_7']
    data_8 = request.form['data_8']
    data_9 = request.form['data_9']
    
    # elasticsearch 전송코드
    data_load.input_data('bmc', data_1, data_2, data_3, data_4, data_5, data_6, data_7, data_8, data_9)

    data.save(data_1, data_2, data_3, data_4, data_5, data_6, data_7, data_8, data_9)

    df = pd.read_csv("data.csv")
    df = df.sort_index(ascending=False)
    df.reset_index(inplace=True)

    df = preprocessing.txt(df, ' data_1', ' data_2', ' data_3',' data_4',' data_5',' data_6',' data_7',' data_8',' data_9')
    df.to_csv('txt.csv')
    alpha_dic = pd.read_csv('untokenized_eng_df.csv')
    df = preprocessing.kor(df, alpha_dic)
    input_df = preprocessing.to_input(df)
    print(df)
    print(input_df)
    new_bm = df.loc[0]['text']
    print(new_bm)
    # new = "This is OUTPUT"
    ##############################################################################

    device = torch.device("cuda:0")

    num_class = 3
    max_len = 512
    drop_out_rate = 0.2
    batch_size = 4
    column_name = 'text'
    labels = '파트너십'
    filename = 'fully_labelled_df_2'

    class BERTDataset(Dataset):
        def __init__(self, dataset, bert_tokenizer, max_len, pad, pair, column_name=column_name, labels=labels):
            transform = nlp.data.BERTSentenceTransform(
                bert_tokenizer, max_seq_length=max_len, pad=pad, pair=pair)

            sent_data = []
            for i in range(len(dataset)):
                sent_data.append([str(dataset.iloc[i][column_name]), dataset.iloc[i][labels]])

            self.sentences = [transform([i[0]]) for i in sent_data]
            self.labels = [np.int32(i[1]) for i in sent_data]

        def __getitem__(self, i):
            return self.sentences[i] + (self.labels[i],)

        def __len__(self):
            return len(self.labels)



    class BERTClassifier(nn.Module):
        def __init__(self,
                    bert,
                    hidden_size=768,
                    num_classes=num_class,
                    dr_rate=None,
                    params=None):
            super(BERTClassifier, self).__init__()
            self.bert = bert
            self.dr_rate = dr_rate

            self.classifier = nn.Linear(hidden_size, num_classes)
            if dr_rate:
                self.dropout = nn.Dropout(p=dr_rate)

        def gen_attention_mask(self, token_ids, valid_length):
            attention_mask = torch.zeros_like(token_ids)
            for i, v in enumerate(valid_length):
                attention_mask[i][:v] = 1
            return attention_mask.float()

        def forward(self, token_ids, valid_length, segment_ids):
            attention_mask = self.gen_attention_mask(token_ids, valid_length)

            _, pooler = self.bert(input_ids=token_ids, token_type_ids=segment_ids.long(),
                                attention_mask=attention_mask.float().to(token_ids.device))

            if self.dr_rate:
                out = self.dropout(pooler)
            softmax = nn.Softmax(dim=1)
            output = softmax(self.classifier(out))
            # output = self.classifier(out)
            # return self.classifier(out)
            return output
    
    
    # 사전에 BERTDataset와 BERTClassifier를 전역변수로 불러와야함

    bertmodel, vocab = get_pytorch_kobert_model() # 버트 모델, vocab 불러오기
    tokenizer = get_tokenizer() #토큰나이저 불러오기
    tok = nlp.data.BERTSPTokenizer(tokenizer, vocab, lower=False) # vocab 단어 토큰화, tok()에 단어를 넣으면 vocab 속 단어로 토큰화
    
    def predict(data, model_name, output_label, max_len=max_len, dr_rate=drop_out_rate, batch_size=batch_size):
        
        data_train = BERTDataset(data, tok, max_len, True, False) # 토큰화, 정수 인코딩, 패딩
        dataloader = torch.utils.data.DataLoader(data_train, batch_size=batch_size, num_workers=0) # 배치사이즈 적용
        
        model = BERTClassifier(bertmodel, dr_rate=drop_out_rate).to(device) # BERT 불러오기
        model.load_state_dict(torch.load(model_name))         # 학습된 모델 불러오기
        model.eval() # 평가모드

        for batch_id, (token_ids, valid_length, segment_ids, label) in enumerate(dataloader):
            
            token_ids = token_ids.long().to(device)     # token_ids 를 'cuda:0'에 연결
            segment_ids = segment_ids.long().to(device) # segment_ids 를 'cuda:0'에 연결
            valid_length= valid_length                  # 임베딩된 단어 길이
            label = label.long().to(device)             # 라벨링 'cuda:0'에 연결
            out = model(token_ids, valid_length, segment_ids)  # 모델의 softmax 결과값
            
            test_eval=[]
            
            logits=out
            logits = logits.detach().cpu().numpy() # https://byeongjo-kim.tistory.com/32 참고
            
            # 값이 가장 높은 index 찾기
            if np.argmax(logits) == 0:      
                test_eval.append("C")
            elif np.argmax(logits) == 1:
                test_eval.append("B")
            elif np.argmax(logits) == 2:
                test_eval.append("A")
            
        print("{}의 결과는 {}입니다.".format(output_label, test_eval))
        a = "{}".format(test_eval[0])
        return a

    a1 = predict(input_df, '고객 세분화_best_model.pt', '고객 세분화')
    a2 = predict(input_df, '구체적 기재_best_model.pt', '구체적 기재')
    a3 = predict(input_df, '사업의 트렌디 여부_best_model.pt', '트렌디')
    a4 = predict(input_df, '파트너십_best_model.pt', '파트너십')
    a5 = predict(input_df, '핵심자원_best_model.pt', '핵심자원')
    a6 = predict(input_df, '핵심활동 창의성, 효율성_best_model.pt', '핵심활동')

    score1 = preprocessing.trans_score(a1)
    score2 = preprocessing.trans_score(a2)
    score3 = preprocessing.trans_score(a3)
    score4 = preprocessing.trans_score(a4)
    score5 = preprocessing.trans_score(a5)
    score6 = preprocessing.trans_score(a6)

    final, score_sum = preprocessing.Final_Label(score1, score2, score3, score4, score5, score6)

    data_rader = {'구체적 기재':[score2], '사업의 트렌디 여부':[score3], '고객 세분화':[score1], '핵심활동 창의성, 효율성':[score6], '파트너십':[score4], '핵심자원':[score5]}
    data_rader = pd.DataFrame(data_rader)

    # preprocessing.save_radar_chart(data_rader)

    percent = preprocessing.percent_rank(score_sum)


    print(percent)

    # wci = preprocessing.wc_maker(input_df)
    # print(wci)

    # time.sleep(20)

    return render_template('output.html', output1=a1, output2=a2, output3=a3, output4=a4,
    output5=a5, output6=a6, final=final, percent=percent)


@application.route("/list")
def list():
    df = pd.read_csv('txt.csv')
    txt1 = df.loc[0]['text']
    txt2 = df.loc[1]['text']
    txt3 = df.loc[2]['text']
    txt4 = df.loc[3]['text']
    txt5 = df.loc[4]['text']
    txt6 = df.loc[5]['text']
    return render_template("list.html", text1= txt1, text2=txt2, text3= txt3, text4=txt4, text5=txt5, text6=txt6)


application.run(host='0.0.0.0', port=8023)