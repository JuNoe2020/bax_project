# 각 BM 세그먼트를 하나의 Text로 합치는 함수
# df[1-9]는 각각의 데이터프임
# column[1-9]는 텍스트가 있는 각각의 열
import pandas as pd
import numpy as np

import matplotlib.pyplot as plt
from math import pi
from matplotlib.path import Path
from matplotlib.spines import Spine
from matplotlib.transforms import Affine2D

import konlpy
from konlpy.tag import Okt
from konlpy.tag import Kkma
from konlpy.tag import Hannanum
from konlpy.tag import Komoran

import matplotlib as mpl
import matplotlib.pyplot as plt
from IPython.display import set_matplotlib_formats

from wordcloud import WordCloud


data_for_per = pd.read_csv('./data/preprocessed_labelled_final_df.csv')

def txt(df, column1, column2, column3, column4, 
        column5, column6, column7, column8, column9):
    total_df = pd.DataFrame()
    total_df['text'] = "고객 세그먼트는 "+ df[column1] + "." +\
                " 가치제안은 " + df[column2] + "." +\
                " 마케팅채널은 " + df[column3] + "." +\
                " 고객관계는 " + df[column4] + "." +\
                " 수익원은 " + df[column5] + "." +\
                " 핵심활동은 " + df[column6] + "." +\
                " 핵심자원은 " + df[column7] + "." +\
                " 핵심파트너는 " + df[column8] + "." +\
                " 비용구조는 " + df[column9] + "."
    total_df['text'] = total_df['text'].replace('\n', ",")
    return total_df

# 알파벳사전 불러오기
alpha_dic = pd.read_csv('./untokenized_eng_df.csv')

# 알파벳단어를 한글로 바꾸는 함수
# df:변환대상이되는 데이터프레임
# alpha_dic: 알파벳사전
# text_column, untoken_column, kor_column 따로 선언하지 않아도됨
# (df와 alpha_dic의 컬럼명 변경시 입력필요)

def kor(df, alpha_dic, text_column='text', 
               untoken_column='untokenized_word', kor_column='kor'):
    
    alpha_dic = alpha_dic[[untoken_column, kor_column]]
    alpha_dic.dropna(inplace=True)
    alpha_dic.reset_index(inplace=True)

    words = df[text_column][0].split(" ")
    for word in words:
        for i in range(len(alpha_dic)):
            if word == alpha_dic[untoken_column][i]: 
                df.loc[[0],[text_column]] = df[text_column][0].replace(word, alpha_dic[kor_column][i])
    return df

def to_input(df):
    input_df = pd.DataFrame()
    input_df['text'] = df['text']
    input_df['파트너십'] = 10
    # print(df_1)
    input_df = pd.DataFrame(input_df.iloc[0,:]).T
    return input_df


def trans_score(data):
    if data == 'A':
        data = 3
    elif data == 'B':
        data = 2
    else:
        data = 1

    return data

#라벨 컷트라인
# A 컷트라인 :  2.3040000000000003
# B 컷트라인 :  1.9030000000000002
# C 컷트라인 :  1.6200000000000003
# D 컷트라인 :  1.21

def Final_Label(data1, data2, data3, data4, data5, data6):
    
    Label = " "
    Final_score = ( 0.401 * data1 ) + ( 0.219 * data2 ) + ( 0.166 * data3 ) + ( 0.117 * data4 ) + ( 0.053 * data5 ) + ( 0.044 * data6 )
    
    if Final_score >= 2.3040000000000003:
        Label = 'A'
    elif Final_score < 2.3040000000000003 and Final_score >= 1.9030000000000002:
        Label = 'B'
    elif Final_score < 1.9030000000000002 and Final_score >= 1.6200000000000003:
        Label = 'C'
    elif Final_score < 1.6200000000000003 and Final_score >= 1.21:
        Label = 'D'
    else:
        Label = 'E'
    
    print(Label)
    
    return Label, Final_score


score_list = data_for_per['종합점수']

def percent_rank(value, precision = 100, pd_series = score_list):
    trans = np.round((pd_series < value).astype(int).sum()/(len(pd_series) -1), precision)
    percent = (1 - trans) * 100
    percent = round(percent, 2)
    return percent


# 레이더 차트를 저장하는 함수
# df:위 예시용 데이터프레임이 들어가야함
# 현재 디렉토리에 'savefig_smaple.png'로 저장됨

def save_radar_chart(df):
    stack = df.stack()
    stack[stack == 3] = 9
    stack[stack == 2] = 6
    stack[stack == 1] = 3
    df = stack.unstack()

    df = df.rename(columns={'구체적 기재':'Specific description',
                      '사업의 트렌디 여부':'Trendy in business',
                      '고객 세분화':'Customer segmentation',
                      '핵심활동 창의성, 효율성':'Core Activities',
                      '파트너십':'Partnership',
                      '핵심자원':'Core resources'})


    ## 따로 그리기
    labels = df.columns[:]
    num_labels = len(labels)

    angles = [x/float(num_labels)*(2*pi) for x in range(num_labels)] ## 각 등분점
    angles += angles[:1] ## 시작점으로 다시 돌아와야하므로 시작점 추가

    my_palette = plt.cm.get_cmap("Set2", len(df.index))

    # fig = plt.figure(figsize=(10,10))
    # fig.set_facecolor('white')

#     for i, row in df.iterrows():
    color = my_palette(0)
#         data = df.iloc[i].tolist()
    data = df.iloc[0].tolist()
    data += data[:1]

    ax = plt.subplot(1,1,1, polar=True)
    ax.set_theta_offset(pi / 2) ## 시작점
    ax.set_theta_direction(-1) ## 그려지는 방향 시계방향

    plt.xticks(angles[:-1], labels, fontsize=15) ## x축 눈금 라벨
    ax.tick_params(axis='x', which='major', pad=15) ## x축과 눈금 사이에 여백을 준다.

    ax.set_rlabel_position(0) ## y축 각도 설정(degree 단위)
    plt.yticks([3,6,9],['C','B','A'], fontsize=15) ## y축 눈금 설정
    plt.ylim(0,9)

    ax.plot(angles, data, color=color, linewidth=2, linestyle='solid') ## 레이더 차트 출력
    ax.fill(angles, data, color=color, alpha=0.4) ## 도형 안쪽에 색을 채워준다.

    # plt.title(row['기업명'], size=30, color=color,x=-0.2, y=1.2, ha='left', fontproperties=fprop) ## 타이틀은 캐릭터 클래스로 한다.

    plt.tight_layout(pad=5) ## subplot간 패딩 조절
    # plt.show()
    plt.savefig('./static/savefig.jpg')


def wc_maker(df1):
    mpl.rc('font',family='HanaUL') # 시각화 한글 글꼴 설정
    mpl.rc('axes',unicode_minus = True)   # 음수값 글꼴 설정 
    # set_matplotlib_formats('retina') # 글씨체 선명하게 
    okt = Okt()
    comm_list = df1['text'].values.tolist()
    pos_data = pd.DataFrame()
    df_Pos = pd.DataFrame()

    for i in range(0,len(df1['text'])):
        pos_data = okt.pos(df1['text'].values.tolist()[i])
        dfn = pd.DataFrame(pos_data)
        
        df_Pos = pd.concat([df_Pos, dfn])

    pos_data = df_Pos.rename(columns={0:'text',1:'품사'})
    cond1   = (pos_data['품사'] == 'Noun')
    df_Noun = pos_data.loc[cond1]
    df_Noun.head()
    wc = WordCloud(width=800,height=600, font_path='Malgun.ttf').generate(' '.join(df_Noun['text']))
    
    plt.figure(figsize=[10,10])
    plt.imshow(wc)
    wc = plt.savefig('./static/wc_image.jpg')
  
    return wc