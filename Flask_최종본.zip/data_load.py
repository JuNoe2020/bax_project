from datetime import datetime
from elasticsearch import Elasticsearch

# elasticsearch 연결
es = Elasticsearch('http://34.64.84.121:9200')
es.info()

# 동일한 이른의 인덱스가 있을 경우 삭제하고 다시 생성
def make_index(es, index_name):
    if es.indices.exists(index=index_name):
        es.indices.delete(index=index_name)
        es.indices.create(index=index_name)

# 데이터베이스 이름 선언 (엘라스틱에서는 인덱스라 함)



def input_data(index_name, data1, data2, data3, data4, data5, data6, data7, data8, data9):

    # 데이터준비
    doc = { 
            '고객 세그먼트': data1, 
            '가치제안': data2, 
            "마케팅 채널": data3,
            '고객관계': data4, 
            "수익원": data5,
            "핵심활동": data6, 
            "핵심자원": data7,
            "핵심파트너": data8,
            "비용구조": data9}
    make_index(es, index_name)

    # 값 입력
    es.index(index=index_name, doc_type='string', body=doc)
    
    # 새로고침
    es.indices.refresh(index=index_name)
